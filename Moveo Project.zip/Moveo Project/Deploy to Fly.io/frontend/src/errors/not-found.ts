export class NotFoundError extends Error {}
