export class ServerError extends Error { }
