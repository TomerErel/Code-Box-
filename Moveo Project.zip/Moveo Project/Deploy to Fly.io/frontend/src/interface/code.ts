export interface CodeBox {
  id: string,
  title: string;
  code: string;
}
