export class NotFoundError extends Error {}

export class CollisionError extends Error {}
